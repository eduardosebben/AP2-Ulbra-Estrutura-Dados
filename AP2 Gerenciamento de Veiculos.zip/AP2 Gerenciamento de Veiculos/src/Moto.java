public class Moto extends Veiculo {
    private int cilindrada;

    // Métodos de acesso para o atributo cilindrada
    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    // Implementação do método abstrato
    @Override
    public String informacoesVeiculo() {
        return String.format("Moto: Marca: %s, Modelo: %s, Ano: %d, Cilindrada: %dcc",
                marca, modelo, getAno(), cilindrada);
    }
}
