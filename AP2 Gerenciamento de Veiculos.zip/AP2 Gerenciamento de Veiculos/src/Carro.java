public class Carro extends Veiculo {
    public int numeroPortas;

    // Implementação do método abstrato
    @Override
    public String informacoesVeiculo() {
        return String.format("Carro: Marca: %s, Modelo: %s, Ano: %d, Número de Portas: %d",
                marca, modelo, getAno(), numeroPortas);
    }
}

